'use client';

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { 
  Package, 
  DollarSign, 
  Tag, 
  Hash, 
  Eye, 
  EyeOff, 
  TrendingUp, 
  Calculator,
  Sparkles,
  Zap,
  Copy
} from 'lucide-react';

interface VariantData {
  id: string;
  title: string;
  price: number;
  comparePrice: number;
  costPerItem: number;
  sku: string;
  status: 'active' | 'inactive';
  attributes: {
    color: string;
    size: string;
    style: string;
    material: string;
  };
  customFields: {
    [key: string]: string;
  };
  specifications: {
    [key: string]: string;
  };
  highlightedFeatures: Array<{
    title: string;
    description: string;
    icon: string;
  }>;
  media: Array<{
    id: string;
    url: string;
    name: string;
  }>;
  salesChannels: {
    pos: {
      inStock: boolean;
      showInCatalog: boolean;
      displayOrder: number;
    };
    onlineStore: {
      inStock: boolean;
      showInCatalog: boolean;
      discount: number;
      discountType: 'percentage' | 'fixed';
    };
    marketplace: {
      enabled: boolean;
    };
  };
  inventory: {
    [locationId: string]: {
      available: number;
      committed: number;
      unavailable: number;
      incoming: number;
      breakdown: {
        damaged: number;
        qc: number;
        reserved: number;
      };
    };
  };
  dimensions: {
    weight: number;
    length: number;
    width: number;
    height: number;
  };
}

interface BasicInfoFormProps {
  data: VariantData;
  onChange: (field: keyof VariantData, value: any) => void;
}

const BasicInfoForm: React.FC<BasicInfoFormProps> = ({ data, onChange }) => {
  const margin = data.price > data.costPerItem ? 
    ((data.price - data.costPerItem) / data.price * 100).toFixed(1) : '0';
  
  const discount = data.comparePrice > data.price ? 
    ((data.comparePrice - data.price) / data.comparePrice * 100).toFixed(0) : '0';

  return (
    <div className="space-y-6">
      {/* Title and Status Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card className="bg-white border-gray-200 shadow-sm">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-gray-900 rounded-lg">
                    <Package className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <Label htmlFor="title" className="text-sm font-semibold text-gray-700">Variant Title</Label>
                    <p className="text-xs text-gray-500">The name that appears in your store</p>
                  </div>
                </div>
                <Input
                  id="title"
                  value={data.title}
                  onChange={(e) => onChange('title', e.target.value)}
                  placeholder="e.g., Dark Roast - Large Size"
                  className="text-lg font-medium border-gray-200 focus:border-gray-400 focus:ring-gray-400"
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="bg-white border-gray-200 shadow-sm">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-gray-900 rounded-lg">
                    <Eye className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <Label className="text-sm font-semibold text-gray-700">Status</Label>
                    <p className="text-xs text-gray-500">Visibility in store</p>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">
                    {data.status === 'active' ? 'Active' : 'Inactive'}
                  </span>
                  <Switch
                    checked={data.status === 'active'}
                    onCheckedChange={(checked) => onChange('status', checked ? 'active' : 'inactive')}
                  />
                </div>
                <Badge 
                  variant={data.status === 'active' ? 'default' : 'secondary'}
                  className="w-full justify-center"
                >
                  {data.status === 'active' ? '● Visible in Store' : '○ Hidden from Store'}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Pricing Section */}
      <Card className="bg-white border-gray-200 shadow-sm">
        <CardContent className="p-6">
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gray-900 rounded-lg">
                <DollarSign className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Pricing Information</h3>
                <p className="text-sm text-gray-500">Set your selling price and cost structure</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Selling Price */}
              <div className="space-y-3">
                <Label htmlFor="price" className="text-sm font-medium text-gray-700">Selling Price</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={data.price}
                    onChange={(e) => onChange('price', parseFloat(e.target.value) || 0)}
                    className="pl-8 border-gray-200 focus:border-gray-400 focus:ring-gray-400 text-lg font-bold"
                    placeholder="0.00"
                  />
                </div>
                <p className="text-xs text-gray-500">Price customers will pay</p>
              </div>

              {/* Compare Price */}
              <div className="space-y-3">
                <Label htmlFor="comparePrice" className="text-sm font-medium text-gray-700">Compare Price</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    id="comparePrice"
                    type="number"
                    step="0.01"
                    value={data.comparePrice}
                    onChange={(e) => onChange('comparePrice', parseFloat(e.target.value) || 0)}
                    className="pl-8 border-gray-200 focus:border-gray-400 focus:ring-gray-400"
                    placeholder="0.00"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <p className="text-xs text-gray-500">Original price for comparison</p>
                  {data.comparePrice > data.price && (
                    <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 text-xs">
                      {discount}% OFF
                    </Badge>
                  )}
                </div>
              </div>

              {/* Cost Per Item */}
              <div className="space-y-3">
                <Label htmlFor="costPerItem" className="text-sm font-medium text-gray-700">Cost Per Item</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    id="costPerItem"
                    type="number"
                    step="0.01"
                    value={data.costPerItem}
                    onChange={(e) => onChange('costPerItem', parseFloat(e.target.value) || 0)}
                    className="pl-8 border-gray-200 focus:border-gray-400 focus:ring-gray-400"
                    placeholder="0.00"
                  />
                </div>
                <p className="text-xs text-gray-500">Your cost to acquire/make</p>
              </div>
            </div>

            {/* Profit Analysis */}
            <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-600">${data.price}</div>
                  <div className="text-xs text-gray-600">Selling Price</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-600">${data.costPerItem}</div>
                  <div className="text-xs text-gray-600">Cost</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-600">${(data.price - data.costPerItem).toFixed(2)}</div>
                  <div className="text-xs text-gray-600">Profit</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600">{margin}%</div>
                  <div className="text-xs text-gray-600">Margin</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SKU and Identification */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-white border-gray-200 shadow-sm">
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gray-900 rounded-lg">
                  <Hash className="h-5 w-5 text-white" />
                </div>
                <div>
                  <Label htmlFor="sku" className="text-sm font-semibold text-gray-700">SKU (Stock Keeping Unit)</Label>
                  <p className="text-xs text-gray-500">Unique identifier for inventory</p>
                </div>
              </div>
              <Input
                id="sku"
                value={data.sku}
                onChange={(e) => onChange('sku', e.target.value)}
                placeholder="e.g., COF-001-DARK-L11G"
                className="font-mono border-gray-200 focus:border-gray-400 focus:ring-gray-400"
              />
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" className="text-xs border-gray-200 hover:bg-gray-50">
                  <Zap className="h-3 w-3 mr-1" />
                  Auto-generate
                </Button>
                <Button variant="outline" size="sm" className="text-xs border-gray-200 hover:bg-gray-50">
                  <Copy className="h-3 w-3 mr-1" />
                  Copy
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-gray-200 shadow-sm">
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gray-900 rounded-lg">
                  <Tag className="h-5 w-5 text-white" />
                </div>
                <div>
                  <Label className="text-sm font-semibold text-gray-700">Variant ID</Label>
                  <p className="text-xs text-gray-500">System-generated identifier</p>
                </div>
              </div>
              <div className="bg-gray-100 px-3 py-2 rounded-md">
                <code className="text-sm font-mono text-gray-700">{data.id}</code>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                  Auto-generated
                </Badge>
                <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                  Read-only
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="bg-gray-900 text-white border-gray-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-white/10 rounded-lg">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold">Quick Actions</h3>
                <p className="text-gray-300 text-sm">Common tasks for this variant</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                <Calculator className="h-4 w-4 mr-1" />
                Calculate Profit
              </Button>
              <Button variant="outline" size="sm" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                <TrendingUp className="h-4 w-4 mr-1" />
                View Analytics
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BasicInfoForm; 