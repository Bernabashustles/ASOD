'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, 
  Trash2, 
  Edit, 
  Copy, 
  Settings, 
  Palette, 
  Ruler, 
  Tag, 
  Layers,
  Grid3X3,
  Table,
  Zap,
  Sparkles
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import VariantCombinationTable from './VariantCombinationTable';

interface AttributesData {
  color: string;
  size: string;
  style: string;
  material: string;
}

interface AttributesFormProps {
  data: AttributesData;
  onChange: (field: keyof AttributesData, value: string) => void;
}

interface VariantAttribute {
  name: string;
  values: string[];
}

interface VariantCombination {
  id: string;
  attributes: { [key: string]: string };
  price: number;
  comparePrice: number;
  sku: string;
  barcode: string;
  weight: number;
  isActive: boolean;
  inventory: number;
  images: string[];
}

const AttributesForm: React.FC<AttributesFormProps> = ({ data, onChange }) => {
  const [attributes, setAttributes] = useState<VariantAttribute[]>([
    { name: 'Color', values: ['Red', 'Blue', 'Green', 'Black', 'White'] },
    { name: 'Size', values: ['XS', 'S', 'M', 'L', 'XL', 'XXL'] },
    { name: 'Style', values: ['Classic', 'Modern', 'Vintage', 'Sporty'] },
    { name: 'Material', values: ['Cotton', 'Polyester', 'Wool', 'Silk', 'Linen'] }
  ]);

  const [combinations, setCombinations] = useState<VariantCombination[]>([]);
  const [isAddingAttribute, setIsAddingAttribute] = useState(false);
  const [newAttributeName, setNewAttributeName] = useState('');
  const [newAttributeValues, setNewAttributeValues] = useState('');

  const predefinedAttributes = [
    { name: 'Color', icon: Palette, values: ['Red', 'Blue', 'Green', 'Black', 'White', 'Yellow', 'Purple', 'Orange'] },
    { name: 'Size', icon: Ruler, values: ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL'] },
    { name: 'Style', icon: Tag, values: ['Classic', 'Modern', 'Vintage', 'Sporty', 'Casual', 'Formal', 'Bohemian'] },
    { name: 'Material', icon: Layers, values: ['Cotton', 'Polyester', 'Wool', 'Silk', 'Linen', 'Denim', 'Leather'] },
    { name: 'Pattern', icon: Grid3X3, values: ['Solid', 'Striped', 'Polka Dot', 'Floral', 'Geometric', 'Abstract'] },
    { name: 'Fit', icon: Settings, values: ['Slim', 'Regular', 'Loose', 'Oversized', 'Tapered'] }
  ];

  const handleAddAttribute = () => {
    if (newAttributeName && newAttributeValues) {
      const values = newAttributeValues.split(',').map(v => v.trim()).filter(v => v);
      setAttributes([...attributes, { name: newAttributeName, values }]);
      setNewAttributeName('');
      setNewAttributeValues('');
      setIsAddingAttribute(false);
    }
  };

  const handleRemoveAttribute = (index: number) => {
    setAttributes(attributes.filter((_, i) => i !== index));
  };

  const handleAddValue = (attributeIndex: number, value: string) => {
    if (value && !attributes[attributeIndex].values.includes(value)) {
      const updated = [...attributes];
      updated[attributeIndex].values.push(value);
      setAttributes(updated);
    }
  };

  const handleRemoveValue = (attributeIndex: number, valueIndex: number) => {
    const updated = [...attributes];
    updated[attributeIndex].values.splice(valueIndex, 1);
    setAttributes(updated);
  };

  const getAttributeIcon = (name: string) => {
    const predefined = predefinedAttributes.find(attr => attr.name === name);
    return predefined ? predefined.icon : Settings;
  };

  const getAttributeColor = (name: string) => {
    const colors = [
      'bg-blue-100 text-blue-800 border-blue-200',
      'bg-green-100 text-green-800 border-green-200',
      'bg-purple-100 text-purple-800 border-purple-200',
      'bg-orange-100 text-orange-800 border-orange-200',
      'bg-pink-100 text-pink-800 border-pink-200',
      'bg-indigo-100 text-indigo-800 border-indigo-200',
      'bg-red-100 text-red-800 border-red-200',
      'bg-yellow-100 text-yellow-800 border-yellow-200'
    ];
    const index = attributes.findIndex(attr => attr.name === name);
    return colors[index % colors.length];
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="attributes" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-slate-100">
          <TabsTrigger value="attributes" className="flex items-center space-x-2">
            <Settings className="h-4 w-4" />
            <span>Attributes</span>
          </TabsTrigger>
          <TabsTrigger value="combinations" className="flex items-center space-x-2">
            <Grid3X3 className="h-4 w-4" />
            <span>Combinations</span>
            <Badge variant="secondary" className="ml-1">
              {combinations.length}
            </Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="attributes" className="space-y-6">
          {/* Current Attributes Display */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {attributes.map((attribute, index) => {
              const IconComponent = getAttributeIcon(attribute.name);
              return (
                <Card key={index} className="bg-gradient-to-br from-slate-50 to-white border-slate-200 hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg">
                          <IconComponent className="h-4 w-4 text-white" />
                        </div>
                        <div>
                          <CardTitle className="text-lg font-semibold text-slate-900">{attribute.name}</CardTitle>
                          <p className="text-sm text-slate-500">{attribute.values.length} values</p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveAttribute(index)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex flex-wrap gap-2">
                        {attribute.values.map((value, valueIndex) => (
                          <Badge 
                            key={valueIndex} 
                            variant="outline" 
                            className={`${getAttributeColor(attribute.name)} hover:scale-105 transition-transform cursor-pointer`}
                            onClick={() => handleRemoveValue(index, valueIndex)}
                          >
                            {value}
                            <span className="ml-1 text-xs opacity-60">×</span>
                          </Badge>
                        ))}
                      </div>
                      <div className="flex space-x-2">
                        <Input
                          placeholder="Add new value..."
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              const target = e.target as HTMLInputElement;
                              handleAddValue(index, target.value);
                              target.value = '';
                            }
                          }}
                          className="flex-1"
                        />
                        <Button size="sm" variant="outline">
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Add New Attribute */}
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-blue-900">
                <Plus className="h-5 w-5" />
                <span>Add New Attribute</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Quick Add Predefined Attributes */}
                <div>
                  <Label className="text-sm font-medium text-slate-700 mb-2 block">Quick Add</Label>
                  <div className="flex flex-wrap gap-2">
                    {predefinedAttributes.map((predefined) => {
                      const IconComponent = predefined.icon;
                      const isAdded = attributes.some(attr => attr.name === predefined.name);
                      return (
                        <Button
                          key={predefined.name}
                          variant="outline"
                          size="sm"
                          disabled={isAdded}
                          onClick={() => {
                            if (!isAdded) {
                              setAttributes([...attributes, { name: predefined.name, values: predefined.values }]);
                            }
                          }}
                          className="flex items-center space-x-2 hover:bg-blue-50 hover:border-blue-300"
                        >
                          <IconComponent className="h-3 w-3" />
                          <span>{predefined.name}</span>
                          {isAdded && <Badge variant="secondary" className="ml-1 text-xs">Added</Badge>}
                        </Button>
                      );
                    })}
                  </div>
                </div>

                {/* Custom Attribute */}
                <div className="space-y-3">
                  <Label className="text-sm font-medium text-slate-700">Custom Attribute</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Input
                      placeholder="Attribute name (e.g., Pattern, Fit, Brand)"
                      value={newAttributeName}
                      onChange={(e) => setNewAttributeName(e.target.value)}
                    />
                    <Input
                      placeholder="Values (comma-separated)"
                      value={newAttributeValues}
                      onChange={(e) => setNewAttributeValues(e.target.value)}
                    />
                  </div>
                  <Button 
                    onClick={handleAddAttribute}
                    disabled={!newAttributeName || !newAttributeValues}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Attribute
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Attribute Statistics */}
          <Card className="bg-gradient-to-r from-slate-900 to-slate-800 text-white">
            <CardContent className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-300">{attributes.length}</div>
                  <div className="text-xs text-slate-300">Attributes</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-300">
                    {attributes.reduce((sum, attr) => sum + attr.values.length, 0)}
                  </div>
                  <div className="text-xs text-slate-300">Total Values</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-300">
                    {attributes.reduce((sum, attr) => sum * attr.values.length, 1)}
                  </div>
                  <div className="text-xs text-slate-300">Possible Combinations</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-orange-300">
                    {Math.min(...attributes.map(attr => attr.values.length))}
                  </div>
                  <div className="text-xs text-slate-300">Min Values</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="combinations" className="space-y-6">
          <VariantCombinationTable
            attributes={attributes}
            combinations={combinations}
            onCombinationsChange={setCombinations}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AttributesForm; 