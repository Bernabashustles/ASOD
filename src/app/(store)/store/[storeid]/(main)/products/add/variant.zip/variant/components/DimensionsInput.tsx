'use client';

import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Ruler, Scale, Package, Calculator } from 'lucide-react';

interface DimensionsData {
  weight: number;
  length: number;
  width: number;
  height: number;
}

interface DimensionsInputProps {
  data: DimensionsData;
  onChange: (value: DimensionsData) => void;
}

const DimensionsInput: React.FC<DimensionsInputProps> = ({ data, onChange }) => {
  const updateDimension = (field: keyof DimensionsData, value: number) => {
    onChange({
      ...data,
      [field]: value
    });
  };

  const calculateVolume = () => {
    return (data.length * data.width * data.height).toFixed(2);
  };

  const calculateDensity = () => {
    const volume = data.length * data.width * data.height;
    if (volume > 0) {
      return (data.weight / volume).toFixed(4);
    }
    return '0.0000';
  };

  const getShippingCategory = () => {
    const volume = data.length * data.width * data.height;
    const weight = data.weight;
    
    if (weight > 10) return { category: 'Heavy', color: 'bg-red-100 text-red-700 border-red-200' };
    if (volume > 1000) return { category: 'Large', color: 'bg-orange-100 text-orange-700 border-orange-200' };
    if (weight > 5) return { category: 'Medium', color: 'bg-yellow-100 text-yellow-700 border-yellow-200' };
    return { category: 'Standard', color: 'bg-green-100 text-green-700 border-green-200' };
  };

  const shippingCategory = getShippingCategory();

  return (
    <div className="space-y-6">
      {/* Weight */}
      <div className="space-y-2">
        <Label htmlFor="weight" className="text-sm font-medium text-gray-700 flex items-center space-x-2">
          <Scale className="h-4 w-4" />
          <span>Weight</span>
        </Label>
        <div className="relative">
          <Input
            id="weight"
            type="number"
            step="0.001"
            value={data.weight}
            onChange={(e) => updateDimension('weight', parseFloat(e.target.value) || 0)}
            placeholder="0.000"
            className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
          />
          <Scale className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
        <div className="text-xs text-gray-500">Enter weight in kilograms (kg)</div>
      </div>

      {/* Dimensions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="length" className="text-sm font-medium text-gray-700 flex items-center space-x-2">
            <Ruler className="h-4 w-4" />
            <span>Length</span>
          </Label>
          <div className="relative">
            <Input
              id="length"
              type="number"
              step="0.1"
              value={data.length}
              onChange={(e) => updateDimension('length', parseFloat(e.target.value) || 0)}
              placeholder="0.0"
              className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
            />
            <Ruler className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
          <div className="text-xs text-gray-500">cm</div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="width" className="text-sm font-medium text-gray-700 flex items-center space-x-2">
            <Ruler className="h-4 w-4" />
            <span>Width</span>
          </Label>
          <div className="relative">
            <Input
              id="width"
              type="number"
              step="0.1"
              value={data.width}
              onChange={(e) => updateDimension('width', parseFloat(e.target.value) || 0)}
              placeholder="0.0"
              className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
            />
            <Ruler className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
          <div className="text-xs text-gray-500">cm</div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="height" className="text-sm font-medium text-gray-700 flex items-center space-x-2">
            <Ruler className="h-4 w-4" />
            <span>Height</span>
          </Label>
          <div className="relative">
            <Input
              id="height"
              type="number"
              step="0.1"
              value={data.height}
              onChange={(e) => updateDimension('height', parseFloat(e.target.value) || 0)}
              placeholder="0.0"
              className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
            />
            <Ruler className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
          <div className="text-xs text-gray-500">cm</div>
        </div>
      </div>

      {/* Calculations */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardContent className="p-4">
          <div className="space-y-4">
            <h4 className="font-medium text-gray-900 flex items-center space-x-2">
              <Calculator className="h-4 w-4" />
              <span>Calculated Values</span>
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{calculateVolume()}</div>
                <div className="text-xs text-gray-600">Volume (cm³)</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-pink-600">{calculateDensity()}</div>
                <div className="text-xs text-gray-600">Density (kg/cm³)</div>
              </div>
              <div className="text-center">
                <Badge variant="outline" className={`text-xs ${shippingCategory.color}`}>
                  {shippingCategory.category}
                </Badge>
                <div className="text-xs text-gray-600 mt-1">Shipping Category</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Shipping Information */}
      <Card className="border-gray-200">
        <CardContent className="p-4">
          <div className="space-y-4">
            <h4 className="font-medium text-gray-900 flex items-center space-x-2">
              <Package className="h-4 w-4" />
              <span>Shipping Information</span>
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Package Dimensions</Label>
                <div className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
                  {data.length} × {data.width} × {data.height} cm
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Package Weight</Label>
                <div className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
                  {data.weight} kg ({data.weight * 2.20462} lbs)
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">Shipping Category</Label>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className={shippingCategory.color}>
                  {shippingCategory.category}
                </Badge>
                <span className="text-xs text-gray-500">
                  {shippingCategory.category === 'Heavy' && 'Requires special handling'}
                  {shippingCategory.category === 'Large' && 'May incur oversized fees'}
                  {shippingCategory.category === 'Medium' && 'Standard shipping rates apply'}
                  {shippingCategory.category === 'Standard' && 'Standard shipping rates apply'}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Presets */}
      <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
        <CardContent className="p-4">
          <div className="space-y-3">
            <h4 className="font-medium text-gray-900">Common Package Sizes</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {[
                { name: 'Small Box', dimensions: { weight: 0.5, length: 10, width: 8, height: 5 } },
                { name: 'Medium Box', dimensions: { weight: 1.0, length: 15, width: 12, height: 8 } },
                { name: 'Large Box', dimensions: { weight: 2.0, length: 20, width: 15, height: 10 } },
                { name: 'Coffee Bag', dimensions: { weight: 0.454, length: 15, width: 10, height: 5 } }
              ].map((preset) => (
                <button
                  key={preset.name}
                  onClick={() => onChange(preset.dimensions)}
                  className="text-left p-2 rounded border border-green-200 hover:border-green-300 hover:bg-green-100 transition-colors"
                >
                  <div className="font-medium text-sm text-gray-900">{preset.name}</div>
                  <div className="text-xs text-gray-500">
                    {preset.dimensions.length}×{preset.dimensions.width}×{preset.dimensions.height}cm, {preset.dimensions.weight}kg
                  </div>
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DimensionsInput; 