'use client';

import React, { useState } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Warehouse, Package, TrendingUp, AlertTriangle, CheckCircle, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface LocationInventory {
  available: number;
  committed: number;
  unavailable: number;
  incoming: number;
  breakdown: {
    damaged: number;
    qc: number;
    reserved: number;
  };
}

interface InventoryData {
  [locationId: string]: LocationInventory;
}

interface InventoryManagerProps {
  data: InventoryData;
  onChange: (value: InventoryData) => void;
}

const InventoryManager: React.FC<InventoryManagerProps> = ({ data, onChange }) => {
  const [isAddingLocation, setIsAddingLocation] = useState(false);
  const [newLocationId, setNewLocationId] = useState('');
  const [newLocationName, setNewLocationName] = useState('');

  const locationNames: { [key: string]: string } = {
    'shop123': 'Main Store',
    'loc456': 'Warehouse A',
    'loc789': 'Distribution Center'
  };

  const updateLocationInventory = (locationId: string, field: string, value: number) => {
    onChange({
      ...data,
      [locationId]: {
        ...data[locationId],
        [field]: value
      }
    });
  };

  const updateBreakdown = (locationId: string, field: string, value: number) => {
    onChange({
      ...data,
      [locationId]: {
        ...data[locationId],
        breakdown: {
          ...data[locationId].breakdown,
          [field]: value
        }
      }
    });
  };

  const addLocation = () => {
    if (newLocationId.trim() && newLocationName.trim()) {
      const newInventory: LocationInventory = {
        available: 0,
        committed: 0,
        unavailable: 0,
        incoming: 0,
        breakdown: {
          damaged: 0,
          qc: 0,
          reserved: 0
        }
      };

      onChange({
        ...data,
        [newLocationId]: newInventory
      });

      // Update location names
      locationNames[newLocationId] = newLocationName;

      setNewLocationId('');
      setNewLocationName('');
      setIsAddingLocation(false);
    }
  };

  const removeLocation = (locationId: string) => {
    const updatedData = { ...data };
    delete updatedData[locationId];
    onChange(updatedData);
  };

  const getTotalInventory = () => {
    return Object.values(data).reduce((total, location) => {
      return total + location.available + location.committed + location.unavailable + location.incoming;
    }, 0);
  };

  const getAvailableInventory = () => {
    return Object.values(data).reduce((total, location) => total + location.available, 0);
  };

  return (
    <div className="space-y-6">
      {/* Inventory Summary */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">{getTotalInventory()}</div>
              <div className="text-xs text-gray-600">Total Stock</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">{getAvailableInventory()}</div>
              <div className="text-xs text-gray-600">Available</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600">
                {Object.values(data).reduce((total, location) => total + location.committed, 0)}
              </div>
              <div className="text-xs text-gray-600">Committed</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">
                {Object.values(data).reduce((total, location) => total + location.incoming, 0)}
              </div>
              <div className="text-xs text-gray-600">Incoming</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Location Inventory Cards */}
      <div className="space-y-4">
        {Object.entries(data).map(([locationId, inventory]) => (
          <Card key={locationId} className="border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Warehouse className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">
                      📍 {locationNames[locationId] || locationId}
                    </h3>
                    <p className="text-sm text-gray-500">Location ID: {locationId}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant={inventory.available > 0 ? 'default' : 'secondary'}>
                    {inventory.available > 0 ? 'In Stock' : 'Out of Stock'}
                  </Badge>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => removeLocation(locationId)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-700 flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Available</span>
                  </Label>
                  <Input
                    type="number"
                    value={inventory.available}
                    onChange={(e) => updateLocationInventory(locationId, 'available', parseInt(e.target.value) || 0)}
                    className="border-gray-300 focus:border-green-500 focus:ring-green-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-700 flex items-center space-x-2">
                    <Package className="h-4 w-4 text-orange-500" />
                    <span>Committed</span>
                  </Label>
                  <Input
                    type="number"
                    value={inventory.committed}
                    onChange={(e) => updateLocationInventory(locationId, 'committed', parseInt(e.target.value) || 0)}
                    className="border-gray-300 focus:border-orange-500 focus:ring-orange-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-700 flex items-center space-x-2">
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                    <span>Unavailable</span>
                  </Label>
                  <Input
                    type="number"
                    value={inventory.unavailable}
                    onChange={(e) => updateLocationInventory(locationId, 'unavailable', parseInt(e.target.value) || 0)}
                    className="border-gray-300 focus:border-red-500 focus:ring-red-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-700 flex items-center space-x-2">
                    <TrendingUp className="h-4 w-4 text-purple-500" />
                    <span>Incoming</span>
                  </Label>
                  <Input
                    type="number"
                    value={inventory.incoming}
                    onChange={(e) => updateLocationInventory(locationId, 'incoming', parseInt(e.target.value) || 0)}
                    className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                  />
                </div>
              </div>

              {/* Breakdown */}
              <div className="border-t pt-4">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Breakdown</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs font-medium text-gray-600">Damaged</Label>
                    <Input
                      type="number"
                      value={inventory.breakdown.damaged}
                      onChange={(e) => updateBreakdown(locationId, 'damaged', parseInt(e.target.value) || 0)}
                      className="h-8 text-sm border-gray-300 focus:border-red-500 focus:ring-red-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-medium text-gray-600">QC</Label>
                    <Input
                      type="number"
                      value={inventory.breakdown.qc}
                      onChange={(e) => updateBreakdown(locationId, 'qc', parseInt(e.target.value) || 0)}
                      className="h-8 text-sm border-gray-300 focus:border-yellow-500 focus:ring-yellow-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-medium text-gray-600">Reserved</Label>
                    <Input
                      type="number"
                      value={inventory.breakdown.reserved}
                      onChange={(e) => updateBreakdown(locationId, 'reserved', parseInt(e.target.value) || 0)}
                      className="h-8 text-sm border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Add New Location */}
      <Dialog open={isAddingLocation} onOpenChange={setIsAddingLocation}>
        <DialogTrigger asChild>
          <Button
            variant="outline"
            className="w-full border-dashed border-2 border-gray-300 hover:border-blue-500 hover:bg-blue-50"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Inventory Location
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Inventory Location</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="locationId" className="text-sm font-medium text-gray-700">
                Location ID
              </Label>
              <Input
                id="locationId"
                value={newLocationId}
                onChange={(e) => setNewLocationId(e.target.value)}
                placeholder="e.g., loc789"
                className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="locationName" className="text-sm font-medium text-gray-700">
                Location Name
              </Label>
              <Input
                id="locationName"
                value={newLocationName}
                onChange={(e) => setNewLocationName(e.target.value)}
                placeholder="e.g., Distribution Center"
                className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button
                variant="outline"
                onClick={() => {
                  setIsAddingLocation(false);
                  setNewLocationId('');
                  setNewLocationName('');
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={addLocation}
                disabled={!newLocationId.trim() || !newLocationName.trim()}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Add Location
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Quick Add Suggestions */}
      {Object.keys(data).length === 0 && (
        <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="space-y-3">
              <h4 className="font-medium text-gray-900">Suggested Locations</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {[
                  { id: 'main-store', name: 'Main Store' },
                  { id: 'warehouse-a', name: 'Warehouse A' },
                  { id: 'distribution-center', name: 'Distribution Center' },
                  { id: 'online-fulfillment', name: 'Online Fulfillment' }
                ].map((suggestion) => (
                  <Button
                    key={suggestion.id}
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setNewLocationId(suggestion.id);
                      setNewLocationName(suggestion.name);
                      setIsAddingLocation(true);
                    }}
                    className="justify-start text-left h-auto p-2"
                  >
                    <div>
                      <div className="font-medium text-sm">{suggestion.name}</div>
                      <div className="text-xs text-gray-500">ID: {suggestion.id}</div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default InventoryManager; 