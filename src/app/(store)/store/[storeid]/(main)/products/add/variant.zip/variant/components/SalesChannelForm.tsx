'use client';

import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Store, Globe, ShoppingCart, DollarSign, Eye, Settings } from 'lucide-react';

interface SalesChannelsData {
  pos: {
    inStock: boolean;
    showInCatalog: boolean;
    displayOrder: number;
  };
  onlineStore: {
    inStock: boolean;
    showInCatalog: boolean;
    discount: number;
    discountType: 'percentage' | 'fixed';
  };
  marketplace: {
    enabled: boolean;
  };
}

interface SalesChannelFormProps {
  data: SalesChannelsData;
  onChange: (value: SalesChannelsData) => void;
}

const SalesChannelForm: React.FC<SalesChannelFormProps> = ({ data, onChange }) => {
  const updateChannel = (channel: keyof SalesChannelsData, field: string, value: any) => {
    onChange({
      ...data,
      [channel]: {
        ...data[channel],
        [field]: value
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* POS Channel */}
      <Card className="border-gray-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Store className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-gray-900">POS</h3>
                <p className="text-sm text-gray-500">Point of Sale System</p>
              </div>
            </div>
            <Badge variant={data.pos.inStock ? 'default' : 'secondary'}>
              {data.pos.inStock ? 'Active' : 'Inactive'}
            </Badge>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="pos-instock"
                  checked={data.pos.inStock}
                  onCheckedChange={(checked) => updateChannel('pos', 'inStock', checked)}
                />
                <Label htmlFor="pos-instock" className="text-sm font-medium text-gray-700">
                  In Stock
                </Label>
              </div>
              <Badge variant={data.pos.inStock ? 'default' : 'secondary'} className="text-xs">
                {data.pos.inStock ? '✔️' : '❌'}
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="pos-catalog"
                  checked={data.pos.showInCatalog}
                  onCheckedChange={(checked) => updateChannel('pos', 'showInCatalog', checked)}
                />
                <Label htmlFor="pos-catalog" className="text-sm font-medium text-gray-700">
                  Show in Catalog
                </Label>
              </div>
              <Badge variant={data.pos.showInCatalog ? 'default' : 'secondary'} className="text-xs">
                {data.pos.showInCatalog ? '✔️' : '❌'}
              </Badge>
            </div>

            <div className="space-y-2">
              <Label htmlFor="pos-order" className="text-sm font-medium text-gray-700">
                Display Order
              </Label>
              <div className="relative">
                <Input
                  id="pos-order"
                  type="number"
                  value={data.pos.displayOrder}
                  onChange={(e) => updateChannel('pos', 'displayOrder', parseInt(e.target.value) || 0)}
                  className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
                <Settings className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Online Store Channel */}
      <Card className="border-gray-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Globe className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-gray-900">Online Store</h3>
                <p className="text-sm text-gray-500">E-commerce Website</p>
              </div>
            </div>
            <Badge variant={data.onlineStore.inStock ? 'default' : 'secondary'}>
              {data.onlineStore.inStock ? 'Active' : 'Inactive'}
            </Badge>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="online-instock"
                  checked={data.onlineStore.inStock}
                  onCheckedChange={(checked) => updateChannel('onlineStore', 'inStock', checked)}
                />
                <Label htmlFor="online-instock" className="text-sm font-medium text-gray-700">
                  In Stock
                </Label>
              </div>
              <Badge variant={data.onlineStore.inStock ? 'default' : 'secondary'} className="text-xs">
                {data.onlineStore.inStock ? '✔️' : '❌'}
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="online-catalog"
                  checked={data.onlineStore.showInCatalog}
                  onCheckedChange={(checked) => updateChannel('onlineStore', 'showInCatalog', checked)}
                />
                <Label htmlFor="online-catalog" className="text-sm font-medium text-gray-700">
                  Show in Catalog
                </Label>
              </div>
              <Badge variant={data.onlineStore.showInCatalog ? 'default' : 'secondary'} className="text-xs">
                {data.onlineStore.showInCatalog ? '✔️' : '❌'}
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="online-discount" className="text-sm font-medium text-gray-700">
                  Discount
                </Label>
                <div className="relative">
                  <Input
                    id="online-discount"
                    type="number"
                    value={data.onlineStore.discount}
                    onChange={(e) => updateChannel('onlineStore', 'discount', parseFloat(e.target.value) || 0)}
                    className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="discount-type" className="text-sm font-medium text-gray-700">
                  Discount Type
                </Label>
                <Select
                  value={data.onlineStore.discountType}
                  onValueChange={(value) => updateChannel('onlineStore', 'discountType', value)}
                >
                  <SelectTrigger className="border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage</SelectItem>
                    <SelectItem value="fixed">Fixed Amount</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {data.onlineStore.discount > 0 && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <DollarSign className="h-4 w-4 text-green-600" />
                  <span className="text-sm font-medium text-green-800">
                    {data.onlineStore.discountType === 'percentage' 
                      ? `${data.onlineStore.discount}% off` 
                      : `$${data.onlineStore.discount} off`
                    }
                  </span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Marketplace Channel */}
      <Card className={`border-gray-200 ${!data.marketplace.enabled ? 'opacity-60' : ''}`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <ShoppingCart className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-gray-900">Marketplace</h3>
                <p className="text-sm text-gray-500">Third-party Marketplaces</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={data.marketplace.enabled}
                onCheckedChange={(checked) => updateChannel('marketplace', 'enabled', checked)}
              />
              <Badge variant={data.marketplace.enabled ? 'default' : 'secondary'}>
                {data.marketplace.enabled ? 'Enabled' : 'Disabled'}
              </Badge>
            </div>
          </div>

          {!data.marketplace.enabled && (
            <div className="text-center py-4">
              <div className="text-sm text-gray-500">
                Marketplace integration is currently disabled
              </div>
              <div className="text-xs text-gray-400 mt-1">
                Enable to sell on third-party marketplaces
              </div>
            </div>
          )}

          {data.marketplace.enabled && (
            <div className="space-y-4">
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Eye className="h-4 w-4 text-purple-600" />
                  <span className="text-sm font-medium text-purple-800">Marketplace Settings</span>
                </div>
                <p className="text-sm text-purple-700">
                  Configure marketplace-specific settings when integration is enabled.
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">
                {data.pos.inStock ? 'Active' : 'Inactive'}
              </div>
              <div className="text-xs text-gray-600">POS Status</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">
                {data.onlineStore.inStock ? 'Active' : 'Inactive'}
              </div>
              <div className="text-xs text-gray-600">Online Store</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">
                {data.marketplace.enabled ? 'Enabled' : 'Disabled'}
              </div>
              <div className="text-xs text-gray-600">Marketplace</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SalesChannelForm; 