'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Save, Trash2, Package, Eye, Copy, Download } from 'lucide-react';
import { useRouter } from 'next/navigation';
import VariantFormCard from './components/VariantFormCard';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

interface VariantData {
  id: string;
  title: string;
  price: number;
  comparePrice: number;
  costPerItem: number;
  sku: string;
  status: 'active' | 'inactive';
  attributes: {
    color: string;
    size: string;
    style: string;
    material: string;
  };
  customFields: {
    [key: string]: string;
  };
  specifications: {
    [key: string]: string;
  };
  highlightedFeatures: Array<{
    title: string;
    description: string;
    icon: string;
  }>;
  media: Array<{
    id: string;
    url: string;
    name: string;
  }>;
  salesChannels: {
    pos: {
      inStock: boolean;
      showInCatalog: boolean;
      displayOrder: number;
    };
    onlineStore: {
      inStock: boolean;
      showInCatalog: boolean;
      discount: number;
      discountType: 'percentage' | 'fixed';
    };
    marketplace: {
      enabled: boolean;
    };
  };
  inventory: {
    [locationId: string]: {
      available: number;
      committed: number;
      unavailable: number;
      incoming: number;
      breakdown: {
        damaged: number;
        qc: number;
        reserved: number;
      };
    };
  };
  dimensions: {
    weight: number;
    length: number;
    width: number;
    height: number;
  };
}

const VariantAddPage: React.FC = () => {
  const router = useRouter();
  const [variantData, setVariantData] = useState<VariantData>({
    id: `variant-${Date.now()}`,
    title: 'Dark Roast - Large',
    price: 26.99,
    comparePrice: 31.99,
    costPerItem: 16.50,
    sku: 'COF-001-DARK-L11G',
    status: 'active',
    attributes: {
      color: 'Dark Brown',
      size: '1lb',
      style: 'Dark Roast',
      material: 'Coffee Beans'
    },
    customFields: {
      'Roast Level': 'Dark',
      'Origin': 'Ethiopia',
      'Grind Type': 'Whole Bean'
    },
    specifications: {
      'Caffeine': 'High',
      'Acidity': 'Low',
      'Body': 'Full'
    },
    highlightedFeatures: [
      {
        title: 'Premium Quality',
        description: 'Hand-selected beans',
        icon: 'Star'
      }
    ],
    media: [
      { id: '1', url: '/api/placeholder/300/300', name: 'dark-roast-image1.jpg' },
      { id: '2', url: '/api/placeholder/300/300', name: 'dark-roast-image2.jpg' }
    ],
    salesChannels: {
      pos: {
        inStock: true,
        showInCatalog: true,
        displayOrder: 1
      },
      onlineStore: {
        inStock: true,
        showInCatalog: true,
        discount: 10,
        discountType: 'percentage'
      },
      marketplace: {
        enabled: false
      }
    },
    inventory: {
      'shop123': {
        available: 50,
        committed: 5,
        unavailable: 2,
        incoming: 25,
        breakdown: {
          damaged: 1,
          qc: 1,
          reserved: 0
        }
      },
      'loc456': {
        available: 100,
        committed: 0,
        unavailable: 0,
        incoming: 50,
        breakdown: {
          damaged: 0,
          qc: 0,
          reserved: 0
        }
      }
    },
    dimensions: {
      weight: 0.454,
      length: 15,
      width: 10,
      height: 5
    }
  });

  const handleSave = () => {
    console.log('Saving variant:', variantData);
    router.push('/products/add');
  };

  const handleDelete = () => {
    console.log('Deleting variant:', variantData.id);
    router.push('/products/add');
  };

  const handleBack = () => {
    router.push('/products/add');
  };

  const totalStock = Object.values(variantData.inventory).reduce((sum, loc) => sum + loc.available, 0);
  const margin = variantData.price > variantData.costPerItem ? 
    ((variantData.price - variantData.costPerItem) / variantData.price * 100).toFixed(0) : '0';

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Modern Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBack}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Products</span>
              </Button>
              <Separator orientation="vertical" className="h-6" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  Add Variant
                </h1>
                <p className="text-gray-600 mt-1">Create a new product variant with advanced options</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Badge 
                variant={variantData.status === 'active' ? 'default' : 'secondary'}
                className="px-3 py-1 text-sm font-medium"
              >
                {variantData.status === 'active' ? '● Active' : '○ Inactive'}
              </Badge>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  onClick={handleDelete}
                  className="flex items-center space-x-2 text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                >
                  <Trash2 className="h-4 w-4" />
                  <span>Delete</span>
                </Button>
                <Button
                  onClick={handleSave}
                  className="flex items-center space-x-2 bg-gray-900 hover:bg-gray-800 text-white shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <Save className="h-4 w-4" />
                  <span>Save Variant</span>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          {/* Left Column - Variant Form */}
          <div className="xl:col-span-3">
            <VariantFormCard
              variantData={variantData}
              onVariantChange={setVariantData}
            />
          </div>

          {/* Right Column - Preview & Actions */}
          <div className="space-y-6">
            {/* Variant Preview Card */}
            <Card className="bg-white border-gray-200 shadow-sm">
              <CardHeader className="pb-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-gray-900 rounded-lg">
                    <Package className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-semibold text-gray-900">Variant Preview</CardTitle>
                    <p className="text-sm text-gray-500">Quick overview</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Title</span>
                    <span className="text-sm font-medium text-gray-900 truncate max-w-[150px]">{variantData.title}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Price</span>
                    <span className="text-sm font-bold text-green-600">${variantData.price}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">SKU</span>
                    <span className="text-sm font-mono text-gray-700">{variantData.sku}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Stock</span>
                    <span className="text-sm font-medium text-blue-600">{totalStock} units</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Margin</span>
                    <span className="text-sm font-bold text-purple-600">{margin}%</span>
                  </div>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Media</span>
                  <Badge variant="outline" className="text-xs">
                    {variantData.media.length} files
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions Card */}
            <Card className="bg-white border-gray-200 shadow-sm">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-semibold text-gray-900">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start hover:bg-gray-50 border-gray-200">
                  <Copy className="h-4 w-4 mr-2" />
                  <span>Duplicate Variant</span>
                </Button>
                <Button variant="outline" className="w-full justify-start hover:bg-gray-50 border-gray-200">
                  <Download className="h-4 w-4 mr-2" />
                  <span>Export Data</span>
                </Button>
                <Button variant="outline" className="w-full justify-start hover:bg-gray-50 border-gray-200">
                  <Eye className="h-4 w-4 mr-2" />
                  <span>View Analytics</span>
                </Button>
              </CardContent>
            </Card>

            {/* Status Card */}
            <Card className="bg-gray-900 text-white border-gray-800">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-white/10 rounded-lg">
                      <Package className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Variant Status</h3>
                      <p className="text-gray-300 text-sm">Last updated</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Created</span>
                      <span>{new Date().toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Modified</span>
                      <span>{new Date().toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Version</span>
                      <span>1.0.0</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VariantAddPage; 